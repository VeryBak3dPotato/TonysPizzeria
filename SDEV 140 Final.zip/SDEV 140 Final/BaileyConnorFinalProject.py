import os
import tkinter as tk
from tkinter import messagebox

class PizzaOrderingApp(tk.Tk):
    """Main application class for Tony's Pizzeria Online Ordering System"""

    def __init__(self):
        """Initialize the application"""
        super().__init__()
        self.title("Tony's Pizzeria - Online Ordering")
        self.geometry("600x400")
        self.create_widgets()

    def create_widgets(self):
        """Create widgets for the main application window"""
        # Tony's Pizzeria logo
        self.logo_label = tk.Label(self, text="Tony's Pizzeria", font=("Arial", 24, "bold"))
        self.logo_label.pack(pady=20)

        # Welcome message
        self.welcome_label = tk.Label(self, text="Welcome to Tony's Pizzeria!", font=("Arial", 16))
        self.welcome_label.pack()

        # Navigation buttons
        self.menu_button = tk.Button(self, text="Browse Menu", command=self.open_menu_window)
        self.menu_button.pack(pady=10)

        self.cart_button = tk.Button(self, text="View Cart", command=self.open_cart_window)
        self.cart_button.pack(pady=5)

        self.checkout_button = tk.Button(self, text="Checkout", command=self.open_checkout_window)
        self.checkout_button.pack(pady=5)

        # Cart
        self.cart = []

    def open_menu_window(self):
        """Open the Menu Window"""
        menu_window = MenuWindow(self, self.add_to_cart)
        menu_window.grab_set()  # Prevent interaction with main window while menu window is open

    def open_cart_window(self):
        """Open the Cart Window"""
        cart_window = tk.Toplevel(self)
        cart_window.title("Cart")
        cart_window.geometry("400x300")

        # Cart items
        if self.cart:
            cart_label = tk.Label(cart_window, text="Cart items:", font=("Arial", 12, "bold"))
            cart_label.pack(pady=10)

            for item in self.cart:
                cart_item_label = tk.Label(cart_window, text=f"{item['name']} - ${item['price']:.2f}", font=("Arial", 10))
                cart_item_label.pack(anchor=tk.W)
        else:
            empty_cart_label = tk.Label(cart_window, text="Your cart is empty.", font=("Arial", 12))
            empty_cart_label.pack(pady=10)

    def open_checkout_window(self):
        """Open the Checkout Window"""
        if self.cart:
            self.checkout_window = CheckoutWindow(self, self.cart)
        else:
            messagebox.showinfo("Empty Cart", "Your cart is empty. Please add items to your cart before proceeding to checkout.")

    def add_to_cart(self, item):
        """Add item to cart"""
        self.cart.append(item)
        messagebox.showinfo("Item Added", f"{item['name']} has been added to your cart.")

class MenuWindow(tk.Toplevel):
    """Class representing the Menu Window"""

    def __init__(self, parent, add_to_cart_callback):
        """Initialize the Menu Window"""
        super().__init__(parent)
        self.title("Menu")
        self.geometry("700x400")
        self.add_to_cart_callback = add_to_cart_callback
        self.menu_window()

    def menu_window(self):
        """Create widgets for displaying menu items"""
        # Menu title
        self.menu_title = tk.Label(self, text="Menu", font=("Arial", 16, "bold"))
        self.menu_title.pack(pady=10)

        # Frame to hold menu items
        self.menu_frame = tk.Frame(self)
        self.menu_frame.pack(fill=tk.BOTH, expand=True)

        # Canvas for menu items
        self.canvas = tk.Canvas(self.menu_frame)
        self.canvas.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)

        # Scrollbar for canvas
        self.scrollbar = tk.Scrollbar(self.menu_frame, orient=tk.VERTICAL, command=self.canvas.yview)
        self.scrollbar.pack(side=tk.RIGHT, fill=tk.Y)
        self.canvas.configure(yscrollcommand=self.scrollbar.set)

        # Frame to contain menu items on canvas
        self.menu_items_frame = tk.Frame(self.canvas)
        self.canvas.create_window((0, 0), window=self.menu_items_frame, anchor=tk.NW)

        # Menu items
        menu_items = [
            {"name": "Margherita Pizza", "description": "Tomato sauce, mozzarella cheese, basil", "price": 10.99, "image": "margherita.png"},
            {"name": "Pepperoni Pizza", "description": "Tomato sauce, mozzarella cheese, pepperoni", "price": 12.99, "image": "pepperoni.png"},
            {"name": "Vegetarian Pizza", "description": "Tomato sauce, mozzarella cheese, assorted vegetables", "price": 11.99, "image": "vegetarian.png"},
            {"name": "BBQ Chicken Pizza", "description": "Barbecue sauce, mozzarella cheese, grilled chicken", "price": 13.99, "image": "bbq_chicken.png"},
            {"name": "Supreme Pizza", "description": "Tomato sauce, mozzarella cheese, pepperoni, sausage, onions, peppers, olives", "price": 14.99, "image": "supreme.png"}
        ]

        for item in menu_items:
            item_frame = tk.Frame(self.menu_items_frame, bd=1, relief=tk.RAISED, padx=10, pady=5)
            item_frame.pack(fill=tk.X, padx=10, pady=5)

            # Load image
            image_path = os.path.join(os.path.dirname(__file__), item['image'])
            image = tk.PhotoImage(file=image_path)
            image_label = tk.Label(item_frame, image=image)
            image_label.image = image
            image_label.pack(side=tk.LEFT)

            item_info_frame = tk.Frame(item_frame)
            item_info_frame.pack(side=tk.LEFT, padx=10)

            item_label = tk.Label(item_info_frame, text=f"{item['name']} - ${item['price']:.2f}", font=("Arial", 12, "bold"))
            item_label.pack(anchor=tk.W)

            description_label = tk.Label(item_info_frame, text=item['description'], font=("Arial", 10))
            description_label.pack(anchor=tk.W)

            add_to_cart_button = tk.Button(item_info_frame, text="Add to Cart", command=lambda item=item: self.add_to_cart(item))
            add_to_cart_button.pack(anchor=tk.W)

        # Bind canvas to scrollbar
        self.canvas.bind('<Configure>', self.on_canvas_configure)
        self.menu_items_frame.bind('<Configure>', self.on_frame_configure)

    def on_canvas_configure(self, event):
        """Configure canvas scrolling"""
        self.canvas.configure(scrollregion=self.canvas.bbox("all"))

    def on_frame_configure(self, event):
        """Update canvas scroll region to encompass inner frame"""
        self.canvas.configure(scrollregion=self.canvas.bbox("all"))

    def add_to_cart(self, item):
        """Callback function to add item to cart"""
        self.add_to_cart_callback(item)


class CheckoutWindow(tk.Toplevel):
    """Class representing the Checkout Window"""

    TAX_RATE = 0.07

    def __init__(self, parent, cart):
        """Initialize the Checkout Window"""
        super().__init__(parent)
        self.title("Checkout")
        self.geometry("400x400")
        self.cart = cart
        self.tip = 0
        self.checkout_window()

    def checkout_window(self):
        """Create widgets for displaying cart items and total"""
        # Checkout title
        self.checkout_title = tk.Label(self, text="Checkout", font=("Arial", 16, "bold"))
        self.checkout_title.pack(pady=10)

        # Create a frame to hold all checkout widgets
        checkout_frame = tk.Frame(self)
        checkout_frame.pack(fill=tk.BOTH, expand=True)

        # Create a canvas to contain all checkout widgets
        canvas = tk.Canvas(checkout_frame)
        canvas.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)

        # Create a scrollbar for the canvas
        scrollbar = tk.Scrollbar(checkout_frame, orient=tk.VERTICAL, command=canvas.yview)
        scrollbar.pack(side=tk.RIGHT, fill=tk.Y)
        canvas.configure(yscrollcommand=scrollbar.set)

        # Create a frame to contain all checkout widgets on canvas
        checkout_container = tk.Frame(canvas)
        canvas.create_window((0, 0), window=checkout_container, anchor=tk.NW)

        # Display cart items and total
        if self.cart:
            cart_label = tk.Label(checkout_container, text="Cart items:", font=("Arial", 12, "bold"))
            cart_label.pack(pady=5)

            # Create a frame to hold cart items
            cart_items_frame = tk.Frame(checkout_container)
            cart_items_frame.pack(fill=tk.X)

            for item in self.cart:
                item_frame = tk.Frame(cart_items_frame)
                item_frame.pack(fill=tk.X, padx=10, pady=5)

                # Load image
                image_path = os.path.join(os.path.dirname(__file__), item['image'])
                image = tk.PhotoImage(file=image_path)
                image_label = tk.Label(item_frame, image=image)
                image_label.image = image
                image_label.pack(side=tk.LEFT)

                item_info_frame = tk.Frame(item_frame)
                item_info_frame.pack(side=tk.LEFT, padx=10)

                item_label = tk.Label(item_info_frame, text=f"{item['name']} - ${item['price']:.2f}", font=("Arial", 12, "bold"))
                item_label.pack(anchor=tk.W)

                remove_button = tk.Button(item_info_frame, text="Remove", command=lambda item=item: self.remove_from_cart(item))
                remove_button.pack(anchor=tk.W)

        else:
            empty_cart_label = tk.Label(checkout_container, text="Your cart is empty.", font=("Arial", 12))
            empty_cart_label.pack(pady=10)

        # Create a frame to hold total and payment widgets
        total_frame = tk.Frame(checkout_container)
        total_frame.pack(pady=10)

        subtotal = sum(item['price'] for item in self.cart)
        tax = subtotal * self.TAX_RATE
        total = subtotal + tax

        # Sales tax
        tax_label = tk.Label(total_frame, text=f"Sales Tax (7%): ${tax:.2f}", font=("Arial", 12))
        tax_label.pack(pady=5)

        # Tip entry
        tip_label = tk.Label(total_frame, text="Enter Tip ($):", font=("Arial", 12))
        tip_label.pack(pady=5)
        self.tip_entry = tk.Entry(total_frame)
        self.tip_entry.pack()

        # Total including tax and tip
        self.total_label = tk.Label(total_frame, text=f"Total (including tax and tip): ${total:.2f}", font=("Arial", 12))
        self.total_label.pack(pady=10)

        # Calculate tip button
        tip_button = tk.Button(total_frame, text="Calculate Tip", command=self.calculate_tip)
        tip_button.pack(pady=5)

        # Payment form (placeholder)
        payment_label = tk.Label(total_frame, text="Payment Information", font=("Arial", 12))
        payment_label.pack(pady=5)

        self.payment_entry = tk.Entry(total_frame, width=40)
        self.payment_entry.pack()

        checkout_button = tk.Button(total_frame, text="Checkout", command=self.process_payment)
        checkout_button.pack(pady=10)

        # Update canvas scroll region
        checkout_container.update_idletasks()
        canvas.config(scrollregion=canvas.bbox("all"))


    def calculate_tip(self):
        """Calculate tip based on user input"""
        try:
            self.tip = float(self.tip_entry.get())
        except ValueError:
            messagebox.showerror("Invalid Tip", "Please enter a valid tip amount.")
            return

        subtotal = sum(item['price'] for item in self.cart)
        tax = subtotal * self.TAX_RATE
        total = subtotal + tax + self.tip

        self.total_label.config(text=f"Total (including tax and tip): ${total:.2f}")

    def process_payment(self):
        """Process payment and display confirmation message"""
        payment_info = self.payment_entry.get()
        if payment_info:
            messagebox.showinfo("Payment Success", "Payment processed successfully. Your order will be delivered soon!")
            self.destroy()
        else:
            messagebox.showwarning("Empty Field", "Please enter your payment information.")

    def remove_from_cart(self, item):
        """Remove item from cart"""
        self.cart.remove(item)
        self.destroy()
        self.open_checkout_window()

if __name__ == "__main__":
    app = PizzaOrderingApp()
    app.mainloop()